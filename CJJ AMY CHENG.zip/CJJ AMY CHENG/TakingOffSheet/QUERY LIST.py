from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import datetime
from PIL import ImageTk
from PIL import Image
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.styles.alignment import Alignment
import pickle
from PIL import ImageGrab
from openpyxl.reader.excel import load_workbook
import os.path

root = Tk()
root.title('QUERY LIST')
root.geometry("780x600+300+50")


def togglecheck(event):
    rowid = my_tree.identify_row(event.y)
    tag = my_tree.item(rowid, "tags")[0]
    tags = list(my_tree.item(rowid, "tags"))
    tags.remove(tag)
    my_tree.item(rowid, tags=tags)
    if tag == "checked":
        my_tree.item(rowid, tags="unchecked")
    else:
        my_tree.item(rowid, tags="checked")

# remove all
def remove_all():
    for record in my_tree.get_children():
        my_tree.delete(record)
        project_box.delete(0, END)
        taker_off_name_box.delete(0, END)

# remove one selected
def remove_one():
    x = my_tree.selection()[0]
    my_tree.delete(x)

# select record
def select_record(e):
    # clear entry boxes
    query_box.delete(0, END)
    assumption_box.delete(0, END)

    # Grab record number
    selected = my_tree.focus()

    # Grab record value
    values = my_tree.item(selected, 'values')
    query_box.insert(0, values[0])
    assumption_box.insert(0, values[1])

# save record
def save_record():

    try:
        input_quantity = float(quantity_box.get())
    except ValueError:
        messagebox.showerror(message="NUMERIC INPUT ONLY")
        quantity_box.delete(0, END)

# add some style
style = ttk.Style()

# pick a them
style.theme_use('default')

# treeview frame
tree_frame = Frame(root)
tree_frame.place(x=10, y=83)

# scroll bar
tree_scroll = Scrollbar(tree_frame)
tree_scroll.pack(side=RIGHT, fill=Y)

my_tree = ttk.Treeview(tree_frame, yscrollcommand=tree_scroll.set, selectmode="extended")
my_tree.pack()

# configure
tree_scroll.configure(command=my_tree.yview_scroll)

# define column
my_tree['columns'] = ("QUERY", "ASSUMPTION")

# Formate the column
my_tree.column("#0", anchor=CENTER, width=50)
my_tree.column("QUERY", anchor=W, width=320)
my_tree.column("ASSUMPTION", anchor=CENTER, width=320)

im_checked = ImageTk.PhotoImage(Image.open("checked.png"))
im_unchecked = ImageTk.PhotoImage(Image.open("unchecked.png"))

style = ttk.Style(my_tree)
style.configure('Treeview', rowheight=28)

# Create Headings
my_tree.heading("#0", text="", anchor=CENTER)
my_tree.heading("QUERY", text="QUERY", anchor=CENTER)
my_tree.heading("ASSUMPTION", text="ASSUMPTION", anchor=CENTER)

my_tree.tag_configure('checked', image=im_checked)
my_tree.tag_configure('unchecked', image=im_unchecked)

# add data
data = []

global count

count = 0
for record in data:
    my_tree.insert(parent='', index='end', lid=count, text="", values=(record))
    count += 1

# pack to screen
time_frame = Frame(root)
time_frame.place(x=625, y=20)

current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
time_label = Label(time_frame, text=current_time)
time_label.pack()

name_frame = Frame(root)
name_frame.pack()

project_frame = Frame(root)
project_frame.place(x=10, y=55)

query_list_label = Label(name_frame, text="QUERY LIST", font=(30))
query_list_label.pack(pady=10)

add_frame = Frame(root)
add_frame.place(x=10, y=380)

query_label = Label(add_frame, text="QUERY")
query_label.grid(row=0, column=0)

assumption_label = Label(add_frame, text="ASSUMPTION")
assumption_label.grid(row=0, column=1)

# ENTRY BOX

query_box = Entry(add_frame, width=57)
query_box.grid(row=1, column=0)

assumption_box = Entry(add_frame, width=57, justify='center')
assumption_box.grid(row=1, column=1)

# add item
def add_item():
    if query_box.get() == "":
        messagebox.showerror(message='PLEASE ENTER THE QUERY')
    elif assumption_box.get() == "":
        messagebox.showerror(message='PLEASE ENTER THE ASSUMPTION')

    else:

        global count
        my_tree.insert(parent='', index='end', iid=count,
                       values=(query_box.get(), assumption_box.get()),
                       tags="unchecked")
        count += 1

        # clear the box
        query_box.delete(0, END)
        assumption_box.delete(0, END)

button_frame = Frame(root)
button_frame.place(x=100, y=440)


def taking_off_paper(toggle=None):
    root.withdraw()
    messagebox.showinfo(message='PLEASE,CONFIRM THE UNIT MEASUREMENT BEFORE DOING THE CALCULATION')

# button add
add_button = Button(button_frame, text="ADD RECORD", command=add_item, width=15)
add_button.grid(row=0, column=0, padx=10)

# remove one
remove_one = Button(button_frame, text="DELETE RECORD", command=remove_one, width=15)
remove_one.grid(row=0, column=2, padx=10)

# remove all
remove_all = Button(button_frame, text="DELETE ALL RECORD", command=remove_all, width=15)
remove_all.grid(row=0, column=3, padx=10)

# save update
save_record = Button(button_frame, text="UPDATE RECORD", command=save_record, width=15)
save_record.grid(row=0, column=1, padx=10)

# bind select record
my_tree.bind("<ButtonRelease-1>", select_record)
my_tree.bind("<Double-1>", togglecheck)

# button taking off paper
add_taking_off_paper = Button(root, text="TAKING OFF PAPER", command=taking_off_paper)
add_taking_off_paper.place(x=620, y=50)


root.mainloop()